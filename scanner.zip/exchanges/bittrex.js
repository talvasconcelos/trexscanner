const bittrex = require('node-bittrex-api')

bittrex.options({
  'verbose' : true,
  'baseUrlv2' : 'https://bittrex.com/Api/v2.0'
})
